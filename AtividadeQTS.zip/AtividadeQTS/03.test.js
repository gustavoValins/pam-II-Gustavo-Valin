
import {assertArrayIncludes} from "https://deno.land/std/testing/asserts.ts" 



Deno.test("Teste Assert Array", () => {
    assertArrayIncludes([1, 2, 3], [1])
    assertArrayIncludes([1, 2, 3], [1, 2])
    assertArrayIncludes(Array.from("lil PeEp"), Array.from("lil"))
});