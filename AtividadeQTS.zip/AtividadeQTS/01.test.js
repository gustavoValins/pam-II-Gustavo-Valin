
import {assertEquals, assertNotEquals} from "https://deno.land/std/testing/asserts.ts" 

Deno.test("Test Assert Equals", () => {
    assertEquals(1, 1);
    assertEquals("exhausted", "exhausted");
   // 
  //exemplo duas constantes da mesma classe  
  class FooFighters {}
    const FooFighters1 = new FooFighters();
    const FooFighters2 = new FooFighters();

    assertEquals(FooFighters1, FooFighters2);
  });
  Deno.test("Teste Assert Not Equals", () => {
    assertNotEquals("So Come On down", "And walk with me");
    class descendents {}
    class dead_Kennedys{}
    const proto_pop_rock   = descendents 
    const california_hardcore = dead_Kennedys
    assertNotEquals(proto_pop_rock, california_hardcore);
  });