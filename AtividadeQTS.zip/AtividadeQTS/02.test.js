/* import { assertEquals, assertStringIncludes, assertArrayIncludes, } from "https://deno.land/std/testing/asserts.ts" */
import {assertStringIncludes} from "https://deno.land/std/testing/asserts.ts" 


Deno.test("Teste Assert String", () => {
    assertStringIncludes("Juice Wrld", "Wrld");
});

